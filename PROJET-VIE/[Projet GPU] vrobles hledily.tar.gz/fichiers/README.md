# MoronStreet
(Hopefully) fast implementation of Conway's game of life
