
#ifndef CONSTANTS_IS_DEF
#define CONSTANTS_IS_DEF


#define WIN_WIDTH   500
#define WIN_HEIGHT  500

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))

#define DEFAULT_DIM 2048


#endif
